/*
 * stdlib.h
 *
 *  Created on: Sep 27, 2018
 *      Author: yiman
 */

#ifndef LIB_STDLIB_H_
#define LIB_STDLIB_H_

void delay(uint32_t ms);

#endif /* LIB_STDLIB_H_ */
